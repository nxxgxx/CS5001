# .github folder

The .github folder is specific to github, so the profile can show on the home page. 