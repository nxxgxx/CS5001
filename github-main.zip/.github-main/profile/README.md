# CS 5001 - Master Repository 

The following repo contains the master copies of assignments and class activities for CS 5001, taught by Albert Lionelle at Northeastern University.

## Syllabi 

* **Current:**  
   :star: :star: [CS 5001 - Fall 2023 - Align Online & Vancouver Online](https://github.com/CS5001-khoury/Handouts/blob/main/syllabi/Fall23.md) :star: :star: 
     
  
* **Past Semesters**
  * [CS 5001 - Spring 2023 - Vancouver Online & SF Hybrid](https://github.com/CS5001-khoury/Handouts/blob/main/syllabi/Spring23.md)